from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()

cliente = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
modelo = "gpt-4o"

def clasifica_productos(nombre_producto, lista_categorias):
  prompt_sistema = f"""
    Eres un categorizador de productos.
    Debes asumir las categorías presentes en la lista a continuación.

    # Lista de Categorías Válidas
    {lista_categorias.split(",")}

    # Formato de Salida
        Producto: Nombre del Producto
        Categoría: presenta la categoría del producto

    # Ejemplo de Salida
        Producto: Cepillo de dientes con carga solar
        Categoría: Electrónicos Verdes

  """

  respuesta = cliente.chat.completions.create(
    messages = [
      {
        "role": "system",
        "content": prompt_sistema
      },
      {
        "role": "user",
        "content": nombre_producto
      }
    ],
    model = modelo,
    temperature = 1,
    max_tokens = 200            

  ) 

  return respuesta.choices[0].message.content

categorias = input("Liste las categorias separadas por una coma:")

while True:
  producto = input("Ingrese el nombre del producto a clasificar:")
  texto_resultado = clasifica_productos(producto,categorias)
  print(texto_resultado)

